package emsi.ma.ebankingbackend.enums;

public enum OperationType {
    DEBIT, CREDIT
}
