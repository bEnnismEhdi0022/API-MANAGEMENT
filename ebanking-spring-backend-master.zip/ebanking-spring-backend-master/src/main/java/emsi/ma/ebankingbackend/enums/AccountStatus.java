package emsi.ma.ebankingbackend.enums;

public enum AccountStatus {
    CREATED , ACTIVATED , SUSPENDED
}
